from flask import Flask, jsonify, request
from IdMatcherPredictor import IDMatcher
import json

app = Flask('__name__')


@app.route('/')
def home():
    return "Hello world"

@app.route('/api/v1/data', methods=['GET'])
def api_data():
    matcher = IDMatcher("State", "Provider State")
    url = 'https://github.com/chris1610/pbpython/raw/master/data/hospital_account_info.csv'
    data = matcher.read_data(url).to_json()
    return jsonify(data)

@app.route('/api/v1/predict', methods=['GET'])
def predict():
    matcher = IDMatcher("State", "Provider State")
    url1 = 'https://github.com/chris1610/pbpython/raw/master/data/hospital_account_info.csv'
    url2 = 'https://raw.githubusercontent.com/chris1610/pbpython/master/data/hospital_reimbursement.csv'
    dfA = matcher.read_data(url1)
    dfB = matcher.read_data(url2)
    prediction = matcher.predict_id_matches(dfA, dfB, 0.85)
    pred = prediction.to_json()
    return jsonify(pred)


if __name__ == '__main__':
    app.run(debug=True)
